# Python-for-Everybody-Coursera
Coursera courses for the Python for Everybody Specialization by the University of Michigan. This specialization teaches the fundamentals on how to get started on learning to use Python. I for myself started out in a non-technical background and found a way to learn the material. 
