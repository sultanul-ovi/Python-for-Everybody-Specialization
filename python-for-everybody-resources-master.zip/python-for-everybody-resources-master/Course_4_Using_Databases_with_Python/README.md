#### About

[Using Databases with Python](https://www.coursera.org/learn/python-databases) covers chapters 14-16 of the Charles R. Severance 'Python for Everybody: Exploring Data in Python 3' book.

Current repo contains slides with course materials and my solution to the assignments.

[14th chapter](https://www.py4e.com/html3/14-objects) of the Charles R. Severance book.