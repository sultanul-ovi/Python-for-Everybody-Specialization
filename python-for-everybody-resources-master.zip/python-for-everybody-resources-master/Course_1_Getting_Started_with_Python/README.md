#### About

[Programming for Everybody (Getting Started with Python)](https://www.coursera.org/learn/python) covers chapters 1-5 of the Charles R. Severance 'Python for Everybody: Exploring Data in Python 3' book.

Current repo contains slides with course materials and my solution to the assignments.

[1st chapter](https://www.py4e.com/html3/01-intro) of the Charles R. Severance book.