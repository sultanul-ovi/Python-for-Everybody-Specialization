name = input("Enter your name")
print("Hello " + name)

#output "Hello name"
