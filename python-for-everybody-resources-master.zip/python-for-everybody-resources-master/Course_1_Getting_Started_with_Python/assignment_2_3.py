# This first line is provided for you
hrs = float(input("Enter Hours:"))
rate = float(input("Enter Rate:"))
thepay = rate*hrs
thepaystr = str(thepay)
print("Pay: " + thepaystr)

#or
#thepay = float(hrs)*float(rate)
#print("Pay:",thepay)
