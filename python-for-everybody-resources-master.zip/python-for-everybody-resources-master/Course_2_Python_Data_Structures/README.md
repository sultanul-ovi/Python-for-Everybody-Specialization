#### About

[Python Data Structures](https://www.coursera.org/learn/python-data) covers chapters 6-10 of the Charles R. Severance 'Python for Everybody: Exploring Data in Python 3' book.

Current repo contains slides with course materials and my solution to the assignments.

[6th chapter](https://www.py4e.com/html3/06-strings) of the Charles R. Severance book.

#### Notes

- words.txt is used for the asssignment\_7_1.py
- mbox-short.txt is used for the assignments:
 - assignment\_7_2.py
 - assignment\_8_5.py
 - assignment\_9_4.py
 - assignment\_10_2.py
- romeo.txt is used for the assignemnt\8_4.py