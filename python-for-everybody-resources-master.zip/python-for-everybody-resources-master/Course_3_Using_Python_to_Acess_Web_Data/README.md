#### About

[Course Using Python to Acess Web Data](https://ru.coursera.org/learn/python-network-data) covers chapters 11-13 of the Charles R. Severance 'Python for Everybody: Exploring Data in Python 3' book.

Current repo contains slides with course materials and my solution to the assignments.

[11th chapter](https://www.py4e.com/html3/11-regex) of the Charles R. Severance book.

#### Reference materials

[Introduction to Networking](http://www.net-intro.com/) (free textbook)
[Internet History, Technology, and Security](https://www.coursera.org/learn/internet-history) (Coursera Course)

#### Notes

- test.txt is used for the asssignment\_11.py