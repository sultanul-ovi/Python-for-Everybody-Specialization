# Python-for-Everybody-Specialization
Python for Everybody Specialization, my answer, f the course.
