
hours = float(input("Enter Hours: "))
rate = float(input("Enter Rate: "))


gross_pay = hours * rate

print("Pay:", gross_pay)
