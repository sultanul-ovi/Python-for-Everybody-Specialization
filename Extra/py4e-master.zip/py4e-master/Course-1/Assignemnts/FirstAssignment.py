print ('I\'m a happy learner')
