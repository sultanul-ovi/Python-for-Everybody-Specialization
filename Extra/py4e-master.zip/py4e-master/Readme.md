## Python for Everybody Specialization
### University of Michigan

Coursera Specialization :
[Python for Everybody Specialization](https://www.coursera.org/specializations/python)

** 4 Courses : **

*  Course 1: Programming for Everybody (Getting Started with Python):    
   * [Assignemnts](https://github.com/AmaniAbbas/py4e/tree/master/Course-1/Assignemnts)
   * [Quizzes](https://github.com/AmaniAbbas/py4e/tree/master/Course-1/Quizzes)

*  Course 2: Python Data Structures:       
    * [Assignemnts](https://github.com/AmaniAbbas/py4e/tree/master/Course-2/Assignments)
    * [Quizzes](https://github.com/AmaniAbbas/py4e/tree/master/Course-2/Quizzes)

*  Course 3: Using Python to Access Web Data:
    * [Assignemnts](https://github.com/AmaniAbbas/py4e/tree/master/Course-3/Assignments)
    * [Quizzes](https://github.com/AmaniAbbas/py4e/tree/master/Course-3/Quizzes)

*  Course 4: Using Databases with Python:
    * [5 Weeks: Assignments and Quizzes](https://github.com/AmaniAbbas/py4e/tree/master/Course-4)
