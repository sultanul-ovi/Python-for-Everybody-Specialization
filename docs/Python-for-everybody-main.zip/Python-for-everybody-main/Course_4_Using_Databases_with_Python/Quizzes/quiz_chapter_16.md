** 1. What is the most common Unicode encoding when moving data between systems?**

    1) UTF-8
    2) UTF-32
    3) UTF-16
    4) UTF-128
    5) UTF-64

_Answer is 1) UTF-8_

** 2. What is the decimal (Base-10) numeric value for the upper case letter "G" in the ASCII character set?**

    1) 256
    2) 17
    3) 142
    4) 7
    5) 71

_Answer is 5) 71_

** 3. What word does the following sequence of numbers represent in ASCII:**

``` 108, 105, 115, 116```

    1) first
    2) dict
    3) list
    4) mist
    5) webs

_Answer is 3) list_

** 4. How are strings stored internally in Python 3?**

    1) UTF-16
    2) EBCDIC
    3) inverted
    4) Unicode
    5) bubble memory

_Answer is 4) Unicode_

** 5. When reading data across the network (i.e. from a URL) in Python 3, what method must be used to convert it to the internal format used by strings?**

    1) encode()
    2) rstrip()
    3) split()
    4) decode()
    5) internal()

_Answer is 4) decode()_
