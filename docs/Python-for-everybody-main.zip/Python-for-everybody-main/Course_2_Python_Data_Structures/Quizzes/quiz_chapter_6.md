** 1- What does the following Python Program print out?**
```Python
str1 = "Hello"
str2 = 'there'
bob = str1 + str2
print(bob)
```
    1) Hellothere
    2) 0
    3) Hello
       there
    4) Hello

_Answer is 1) Hellothere_

** 2- What does the following Python program print out?**
```Python
x = '40'
y = int(x) + 2
print(y)
```
    1) int402
    2) 42
    3) 402
    4) x2

_Answer is 2) 42_

** 3- How would you use the index operator [] to print out the letter q from the following string? **
```Python
x = 'From marquard@uct.ac.za'
```
    1) print x[-1]
    2) print(x[7])
    3) print(x[q])
    4) print(x[9])
    5) print(x[8])

_Answer is 5) print(x[8])_

** 4- How would you use string slicing [:] to print out 'uct' from the following string?**
```Python
x = 'From marquard@uct.ac.za'
```
    1) print(x[14:17])
    2) print(x[14:3])
    3) print(x[14/17])
    4) print(x[14+17])
    5) print(x[15:3])
    6) print(x[15:18])

_Answer is 1) print(x[14:17])_

** 5- What is the iteration variable in the following Python code?**
```Python
for letter in 'banana' :
    print(letter)
```
    1) in
    2) print
    3) letter
    4) for
    5) 'banana'

_Answer is 3) letter_

** 6- What does the following Python code print out?**
```Python
print(len('banana')*7)
```
    1) 42
    2) banana7
    3) bananabananabananabananabananabananabanana
    4) 0

_Answer is 1) 42_

** 7- How would you print out the following variable in all upper case in Python?**
```Python
greet = 'Hello Bob'
```
```Python
1)
int i=0;
char c;
while (greet[i]){
  c=greet[i];
  putchar(toupper(c));
  i++;
}
```
```Python
2)
puts(greet.ucase);
```
```Python
3)
print(upper(greet))
```
```Python
4)
print(greet.upper())
```
_Answer is 4) print(greet.upper())_

** 8- Which of the following is not a valid string method in Python?**

    1) shout()
    2) split()
    3) join()
    4) startswith()

_Answer is 1) shout()_

** 9- What will the following Python code print out?**
```Python
data = 'From stephen.marquard@uct.ac.za Sat Jan  5 09:14:16 2008'
pos = data.find('.')
print(data[pos:pos+3])
```
    1) Sat
    2) .ma
    3) uct
    4) mar

_Answer is 2) .ma_

** 10- Which of the following string methods removes whitespace from both the beginning and end of a string? **

    1) strip()
    2) strtrunc()
    3) split()
    4) wsrem()

_Answer is 1) strip()_
